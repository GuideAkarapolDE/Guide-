
public class BMI {

    public double BMI;
public void printInfo(){
    System.out.println("Your BMI:" + String.format("%.2f", BMI));
}
}
